// SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC
//
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "ttnn-pybind/pybind_fwd.hpp"

namespace ttnn::operations::experimental::minimal_matmul::detail {
namespace py = pybind11;
void py_bind_minimal_matmul(py::module& module);

}  // namespace ttnn::operations::experimental::minimal_matmul::detail
